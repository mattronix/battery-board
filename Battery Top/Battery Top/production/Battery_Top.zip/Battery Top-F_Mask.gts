G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.3*
G04 #@! TF.CreationDate,2026-06-05T16:24:13+02:00*
G04 #@! TF.ProjectId,Battery Top,42617474-6572-4792-9054-6f702e6b6963,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3) date 2026-06-05 16:24:13*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.250000X-0.375000X-0.625000X0.375000X-0.625000X0.375000X0.625000X-0.375000X0.625000X0*%
%ADD11RoundRect,0.250000X0.725000X-0.600000X0.725000X0.600000X-0.725000X0.600000X-0.725000X-0.600000X0*%
%ADD12O,1.950000X1.700000*%
%ADD13C,7.000000*%
%ADD14C,2.500000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,F1*
X139400000Y-92500000D03*
X136600000Y-92500000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,J1*
X136500000Y-103000000D03*
D12*
X136500000Y-100500000D03*
X136500000Y-98000000D03*
G04 #@! TD*
D13*
G04 #@! TO.C,J4*
X177982557Y-100000780D03*
G04 #@! TD*
D14*
G04 #@! TO.C,J2*
X151000000Y-104000000D03*
G04 #@! TD*
G04 #@! TO.C,J3*
X151000000Y-96000000D03*
G04 #@! TD*
G04 #@! TO.C,J5*
X151000000Y-100000000D03*
G04 #@! TD*
D13*
G04 #@! TO.C,J6*
X123982556Y-100000780D03*
G04 #@! TD*
M02*
